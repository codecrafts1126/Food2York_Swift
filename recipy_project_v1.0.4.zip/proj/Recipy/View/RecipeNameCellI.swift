//
//  RecipeNameCellI.swift
//  Recipy
//
//  Created by Sucharu on 11/08/19.
//  Copyright © 2019 Sebastian Jolly. All rights reserved.
//

import UIKit

class RecipeNameCellI: UITableViewCell {
    static let identifier = "RecipeNameCell"

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
