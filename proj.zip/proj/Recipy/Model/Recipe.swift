//
//  Recipe.swift
//  Recipy
//
//  Created by Sebastian Jolly on 7/21/19.
//  Copyright © 2019 Sebastian Jolly. All rights reserved.
//

import Foundation

class Recipe:NSObject,NSCoding {
    
    
    var recipeId: String = ""
    var imageUrl: URL
    var sourceUrl: URL
    var f2fUrl: URL
    var title: String
    var publisher: String
    var publisherUrl: URL
    var socialRank: Double
    var ingredients: [String]?  // Only present on the Search requests
    var page: Int?              // Only on the Get requests
    var addedToFavoriteOn:Double = 0.0
    var savedObject:[String:Any]
    
    init?(json: [String: Any]) {
        // First we make sure that the non-optional fields are present in the Json
        // else the initialisation fails
        guard
            let recipeId = json["recipe_id"] as? String,
            let imageUrlRaw = json["image_url"] as? String,
            let sourceUrlRaw = json["source_url"] as? String,
            let f2fUrlRaw = json["f2f_url"] as? String,
            let title = json["title"] as? String,
            let publisher = json["publisher"] as? String,
            let publisherUrlRaw = json["publisher_url"] as? String,
            let socialRank = json["social_rank"] as? Double
            else {
                return nil
        }
        
        
        // We try to create URL from the string retreived
        // else the initialisation fails
        guard
            let imageUrl = URL(string: imageUrlRaw),
            let sourceUrl = URL(string: sourceUrlRaw),
            let f2fUrl = URL(string: f2fUrlRaw),
            let publisherUrl = URL(string: publisherUrlRaw)
            else {
                return nil
        }
        
        // We assign the retreived value and the optionals one to the our recipe
        self.savedObject = json
        self.recipeId = recipeId
        self.imageUrl = imageUrl
        self.sourceUrl = sourceUrl
        self.f2fUrl = f2fUrl
        self.title = title
        self.publisher = publisher
        self.publisherUrl = publisherUrl
        self.socialRank = socialRank
        self.ingredients = json["ingredients"] as? [String]
        self.page = json["page"] as? Int
        
        self.addedToFavoriteOn = json["addedToFavoriteOn"] as? Double ?? 0.0
        
    }
    
    func toJSONForFirebase() -> [String:AnyObject]{
        
        var requestBody:[String:AnyObject] = [String:AnyObject]()
        requestBody["recipe_id"] = self.recipeId as AnyObject
        requestBody["image_url"] = self.imageUrl.absoluteString as AnyObject
        requestBody["source_url"] = self.sourceUrl.absoluteString as AnyObject
        requestBody["f2f_url"]   = self.f2fUrl.absoluteString as AnyObject
        requestBody["title"]   = self.title as AnyObject
        requestBody["publisher"]   = self.publisher as AnyObject
        requestBody["publisher_url"]   = self.publisherUrl.absoluteString as AnyObject
        requestBody["social_rank"]   = self.socialRank as AnyObject
        requestBody["ingredients"]   = self.ingredients as AnyObject
        requestBody["page"]   = self.page as AnyObject
        requestBody["addedToFavoriteOn"] = Date().timeIntervalSince1970 as AnyObject
        return requestBody
    }
    
    func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.savedObject, forKey: "savedReceipe")
        
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        
        guard let obj = aDecoder.decodeObject(forKey: "savedReceipe") as? [String:Any] else { return nil }
        
        self.init(json:obj)
        
    }
    
}
